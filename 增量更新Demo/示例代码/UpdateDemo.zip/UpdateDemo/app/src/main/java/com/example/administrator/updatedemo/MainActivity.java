package com.example.administrator.updatedemo;

import android.content.Context;
import android.content.Intent;
import android.content.pm.PackageManager;
import android.net.Uri;
import android.os.Environment;
import android.support.annotation.NonNull;
import android.support.v4.app.ActivityCompat;
import android.support.v4.content.ContextCompat;
import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.util.Log;
import android.view.View;
import android.widget.Button;
import android.widget.TextView;
import android.widget.Toast;

import java.io.File;

public class MainActivity extends AppCompatActivity implements View.OnClickListener {

    // Used to load the 'native-lib' library on application startup.
    private Button btn1,btn2,btn3;
   private String mPath=Environment.getExternalStorageDirectory().getAbsolutePath()+ File.separator;
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);
        btn1= (Button) this.findViewById(R.id.btn1);
        btn2=(Button)this.findViewById(R.id.btn2);
        btn3=(Button)this.findViewById(R.id.btn3);
        btn1.setOnClickListener(this);
        btn2.setOnClickListener(this);
        btn3.setOnClickListener(this);
        // Example of a call to a native method
        File patchFile = new File(mPath+"patch.patch" );
        if( !patchFile.exists() )
        {
            Toast.makeText(this,"增量更新文件不存在",Toast.LENGTH_SHORT).show();
            return ;
        }else{
            Toast.makeText(this,"增量更新文件存在",Toast.LENGTH_SHORT).show();
        }

        //TODO 是否有权限
        if (ContextCompat.checkSelfPermission(MainActivity.this, android.Manifest.permission.WRITE_EXTERNAL_STORAGE) != PackageManager.PERMISSION_GRANTED) {
            ActivityCompat.requestPermissions(MainActivity.this, new String[]{android.Manifest.permission.WRITE_EXTERNAL_STORAGE}, 2);
        }
    }

    @Override
    public void onClick(View v) {
        switch (v.getId()){
            case R.id.btn1:
                /**
                 * @param oldPath 旧的安装包路径
                 * @param newPath 新的安装包路径
                 * @param patchPath 差分包路径
                 * @return 生成的结果
                 */
                //TODO 拆分,生成差分包，前提是本地要有新的apk,和旧的已经安装的apk，才能生成差分包patch.patch
                    Diffutils.generateDiffApk(ApkUtils.extract(this), mPath + "new.apk", mPath + "patch.patch");
                break;
            case R.id.btn2:
                //TODO 合并，将旧的已经安装的apk和差分包合并成新的apk,之后就可以安装了，真正实用的时候只需要从服务器下载差分包，然后客户端每次启动的时候合并差分包然后重新安装就行了
                    Diffutils.mergeDiffApk(ApkUtils.extract(this), mPath + "new.apk", mPath + "patch.patch");
                break;
            case R.id.btn3:
                File apkFile = new File(mPath+"new.apk" );
                if( !apkFile.exists() ) {
                    Toast.makeText(this, "apk不存在", Toast.LENGTH_SHORT).show();
                    return;
                }else {
                    install(this, mPath + "new.apk");
                }
                break;
        }
    }

    public void onRequestPermissionsResult(int requestCode, @NonNull String[] permissions, @NonNull int[] grantResults) {
        super.onRequestPermissionsResult(requestCode, permissions, grantResults);

        if (requestCode == 2) {
            if (grantResults[0] == PackageManager.PERMISSION_GRANTED) {
                Log.e("","权限申请成功");
            }
        }
    }
    //TODO 安装新的apk
    public static void install(Context context, String apkPath) {
        Intent i = new Intent(Intent.ACTION_VIEW);
        i.setFlags(Intent.FLAG_ACTIVITY_NEW_TASK);
        i.setDataAndType(Uri.fromFile(new File(apkPath)),
                "application/vnd.android.package-archive");
        context.startActivity(i);
        android.os.Process.killProcess(android.os.Process.myPid());
    }
}
