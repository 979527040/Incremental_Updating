package com.example.administrator.updatedemo;

import android.content.Context;
import android.content.pm.ApplicationInfo;

/**
 * Created by Administrator on 2017/8/14.
 */

public class ApkUtils {
    public static String extract(Context context){
        ApplicationInfo applicationInfo=context.getApplicationContext().getApplicationInfo();
        String apkPath=applicationInfo.sourceDir;
        return apkPath;
    }
}
